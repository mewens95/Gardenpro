# GardenPro V2 MVP

Built for a self-employed gardener.

## New in V2
- Recurring jobs: weekly / fortnightly / 4-weekly / 6-weekly
- One-click create next recurring visit
- Schedule view
- Complete jobs
- Customer summary
- Quotes
- Weather-smart planning demo
- Browser local storage

## Open
Open `index.html` in Chrome, Safari or Edge.

## Production roadmap
Connect live weather, maps/route optimisation, SMS, invoices/payments, cloud accounts and mobile notifications.
